package com.example.firstproject.business;

public class MenuItemBase {

}
