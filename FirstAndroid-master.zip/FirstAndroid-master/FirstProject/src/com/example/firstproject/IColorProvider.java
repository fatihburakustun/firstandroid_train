package com.example.firstproject;

public interface IColorProvider {
	public int getRed();
	public void setRed(int val);
	public int getBlue();
	public void setBlue(int val);
	public int getGreen();
	public void setGreen(int val);
}
