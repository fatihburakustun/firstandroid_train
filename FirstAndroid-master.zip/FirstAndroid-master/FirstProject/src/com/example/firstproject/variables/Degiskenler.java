package com.example.firstproject.variables;

public class Degiskenler {

	public static final String Ad="Ad";
	public static final String Soyad="Soyad";
	public static final String URL="URL";
	
	public Degiskenler() {
		// TODO Auto-generated constructor stub	
	}

}
